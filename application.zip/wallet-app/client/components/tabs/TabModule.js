import React from 'react';

const TabModule = ({ children }) => (
  <div>
    {children}
  </div>
);

export default TabModule;
