const cryptoData = [
  {
    name: 'Bitcoin',
    symbol: 'BTC',
  },
  {
    name: 'Ethereum',
    symbol: 'ETH',
  },
  {
    name: 'Binance Coin',
    symbol: 'BNB',
  },
  {
    name: 'Tether',
    symbol: 'USDT',
  },
  {
    name: 'Solana',
    symbol: 'SOL',
  },
  {
    name: 'USD Coin',
    symbol: 'USDC',
  },
  {
    name: 'Cardano',
    symbol: 'ADA',
  },
  {
    name: 'XRP',
    symbol: 'XRP',
  },
  {
    name: 'Terra',
    symbol: 'LUNA',
  },
];

module.exports = cryptoData;
