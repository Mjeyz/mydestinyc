const fiatData = [
  {
    name: 'US Dollar',
    symbol: 'USD',
  },
  {
    name: 'Canadian Dollar',
    symbol: 'CAD',
  },
  {
    name: 'Euro',
    symbol: 'EUR',
  },
  {
    name: 'British Pound Sterling',
    symbol: 'GBP',
  },
  {
    name: 'Australian Dollar',
    symbol: 'AUD',
  },
  {
    name: 'Singapore Dollar',
    symbol: 'SGD',
  },
  {
    name: 'Nigerian Naira',
    symbol: 'NGN',
  },
  {
    name: 'Japanese Yen',
    symbol: 'JPY',
  },
  {
    name: 'Indian Rupee',
    symbol: 'INR',
  },
];

module.exports = fiatData;
